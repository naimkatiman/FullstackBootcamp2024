<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolesAndPermissions extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Role::create(["name" => "admin"]);
        Role::create(["name" => "member"]);

        $permissions = [
            "view_post",
            "edit_post"
        ];

        foreach ($permissions as $permission){
            Permission::create(["name" => $permission]);
        }

        $userAdmin = User::find(1);
        if ($userAdmin){
            $userAdmin->assignRole("admin");
            $userAdmin->givePermissionTo("view_post");
            $userAdmin->givePermissionTo("edit_post");
        }

        $userMember = User::find(2);
        if ($userMember){
            $userMember->assignRole("member");
            $userMember->givePermissionTo("view_post");
        }
    }
}

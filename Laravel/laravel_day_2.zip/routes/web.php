<?php

use App\Http\Controllers\PostController;
use App\Http\Middleware\Authenticate;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/




//Route::prefix("/posts")->middleware([CheckAge::class])->group(function (){
Route::prefix("/posts")->middleware([Authenticate::class])->group(function (){
    Route::get("/create", function () {
//        $user = Auth::user();
//        if (!$user->hasPermissionTo("edit_post"))
//            return response()->json("You dont have permission to view this page", 400);
        return view('post.create');
    });
    Route::get("/", [PostController::class, "index"]);
    Route::post("/", [PostController::class, "store"]);
    Route::get("/{id}", [PostController::class, "show"]);
    Route::delete("/{id}", [PostController::class, "destroy"]);
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/', [App\Http\Controllers\HomeController::class, 'index']);





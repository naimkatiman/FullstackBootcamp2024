<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        if (!$user->hasPermissionTo("view_post"))
            return response()->json("You dont have permission to view this page", 400);
        if ($user->hasRole("admin"))
            $posts = Post::all();
        else
            $posts = $user->posts;
        return view("post.index", ["posts" => $posts]);

    }

    public function show($id)
    {
        $user = Auth::user();
        if (!$user->hasPermissionTo("view_post"))
            return response()->json("You dont have permission to view this page", 400);

        $post = Post::findOrFail($id);
        return view("post.show", ["post" => $post]);
    }

    public function store(Request $request)
    {
        $user = Auth::user();
//        if (!$user->hasPermissionTo("edit_post"))
//            return response()->json("You dont have permission to view this page", 400);

        $validated = $request->validate([
            "title" => "required|max:255",
            "content" => "required|min:10"
        ]);
        $validated["user_id"] = $user->id;
        Post::create($validated);
        return redirect("/posts")->with("status", "Post created successfully!");
    }

    public function destroy($id){
//        $user = Auth::user();
//        if (!$user->hasPermissionTo("edit_post"))
//            return response()->json("You dont have permission to view this page", 400);

        $post = Post::findOrFail($id);
        $post->delete();

        return redirect("/posts")->with("status", "Post deleted successfully!");
    }
}

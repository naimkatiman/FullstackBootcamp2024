@include("navigation")
@if($errors->any())
    <div>
        <ul>
            @foreach($errors->all() as $error)
                <li style="color: red">{{$error}}</li>
            @endforeach
        </ul>
    </div>
@endif


<form action="/posts" method="post">
    @csrf
    <label for="title">Title</label>
    <input type="text" name="title">

    <label for="content">Content</label>
    <textarea name="content"></textarea>

    <button type="submit">Submit</button>
</form>

@include("navigation")
<h1>POSTS</h1>
<a href="/posts/create">Create New Post</a>
@if(session('status'))
    <div style="color: green">
        {{session('status')}}
    </div>
@endif
@foreach($posts as $post)
    <a href="/posts/{{$post->id}}"><h2>{{$post->title}}</h2></a>
    <div>{{$post->content}}</div>
    <form action="/posts/{{$post->id}}" method="POST">
        @csrf
        @method("DELETE")
        <button type="submit">Delete</button>
    </form>
    <hr/>
@endforeach



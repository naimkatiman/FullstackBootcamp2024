@include("navigation")
<h2>{{$post->title}}</h2>
<div>{{$post->content}}</div>

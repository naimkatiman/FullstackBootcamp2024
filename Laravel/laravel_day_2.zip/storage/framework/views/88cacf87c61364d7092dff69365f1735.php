<?php echo $__env->make("navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h2><?php echo e($post->title); ?></h2>
<div><?php echo e($post->content); ?></div>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/post/show.blade.php ENDPATH**/ ?>
<?php echo $__env->make("navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>POSTS</h1>
<a href="/posts/create">Create New Post</a>
<?php if(session('status')): ?>
    <div style="color: green">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="/posts/<?php echo e($post->id); ?>"><h2><?php echo e($post->title); ?></h2></a>
    <div><?php echo e($post->content); ?></div>
    <form action="/posts/<?php echo e($post->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field("DELETE"); ?>
        <button type="submit">Delete</button>
    </form>
    <hr/>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH C:\xampp\htdocs\laravel\resources\views/post/index.blade.php ENDPATH**/ ?>